package com.hx.bigdata

/**
  * Created by fangqing on 8/22/17.
  */
object tmpConstant {
  def init(): Unit ={
    this.x="123"
  }

  var x="abc"
}

package com.hx.bigdata

/**
  * Created by fangqing on 8/22/17.
  */
object tmpGet {
  def getx():String={
    return  tmpConstant.x

  }

}
